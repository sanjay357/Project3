﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;
using Microsoft.AspNet.OData;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Webapi_project_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeCouchbaseService _service;

        public EmployeeController(IEmployeeCouchbaseService service)
        {
            _service = service;
        }
        // GET: api/<EmployeeController>
        [HttpGet]
        //[EnableQuery()]
        public async Task<List<Employees>> Get()
        {
            var couchClient = await _service.Initialize();
            var employees = await _service.GetEmployees(couchClient);
            return employees;
        }



        // GET api/<EmployeeController>/5
        [HttpGet("{id}")]
        //[HttpGet("{department}/{id}")]
        public async Task<Employees> Get(int id)
        {
            var couchClient = await _service.Initialize();
            var employees = await _service.GetEmployeById(couchClient, id);

            return employees;


        }

        // POST api/<EmployeeController>
        [HttpPost]
        public async Task Post([FromBody] Employees value)
        {
            var couchClient = await _service.Initialize();
            await _service.PostEmploye(couchClient, value);

    

        } 

        //update
        // PUT api/<EmployeeController>/5
        [HttpPut("{id}")]
        public async Task<Employees> Put(int id, [FromBody] Employees value)
        {
            var couchClient = await _service.Initialize();
            await _service.PutEmployeById(couchClient, id,value);

            return null;
           
        }

        // DELETE api/<EmployeeController>/5
        [HttpDelete("{id}")]
        public async Task<Employees> Delete(int id)
        {
            var couchClient = await _service.Initialize();
            await _service.DeleteEmployeById(couchClient, id);

            return null;


        }
    }
}
