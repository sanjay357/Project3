﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;
using Microsoft.AspNet.OData;
namespace Webapi_project_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ICouchbaseService _service;

        public LoginController(ICouchbaseService Service)
        {
            this._service = Service;
        }
        // GET: api/<LoginController>
        [HttpGet]
        [EnableQuery()]
        public async Task<List<LoginDetails>> Get()
        {
            var couchClient = await _service.Initialize();
            var loginDetails = await _service.GetLoginDetails(couchClient);
            return loginDetails;
        }

        // POST api/<LoginController>
        [HttpPost]
        public async Task Post([FromBody] LoginDetails form)
        {
            var couchClient = await _service.Initialize();
            await _service.PostLogin(couchClient, form);



        }

    }
}
