﻿using Couchbase;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;

namespace Webapi_project_1.Service
{
    public class CouchbaseService : ICouchbaseService
    {
        public async Task<List<LoginDetails>> GetLoginDetails(ICluster cluster)
        {
            var queryResult = await cluster.QueryAsync<LoginDetails>("SELECT department,id,photo,username,pwd FROM LoginDetails ", new Couchbase.Query.QueryOptions());

            List<LoginDetails> empList = new List<LoginDetails>();

            await foreach (var row in queryResult)
            {
                empList.Add(row);
            }

            return empList;
        }

    
      

        public async Task<ICluster> Initialize()
        {
            var cluster = await Cluster.ConnectAsync("couchbase://localhost", "adm", "sanjay753");
            return cluster;
        }

        public async Task<LoginDetails> PostLogin(ICluster cluster, LoginDetails form)
        {
             var bucket = await cluster.BucketAsync("LoginDetails");
            var collection = bucket.DefaultCollection();
            var idvalue = form.id;
            await collection.InsertAsync(idvalue.ToString(), form);


            return null;
        }
    }
}
