﻿using Castle.Components.DictionaryAdapter;
using Couchbase;
using Couchbase.KeyValue;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;

namespace Webapi_project_1.Service
{
    public class EmployeeCouchbaseService : IEmployeeCouchbaseService
    {
        public async Task<Employees> DeleteEmployeById(ICluster cluster, int id)
        {
            var queryResult = await cluster.QueryAsync<Employees>("SELECT username,name,email,age,location,srccs,phoneNumber,salary,skill,managerName,address,id FROM Employees where id= "  + id.ToString()  , new Couchbase.Query.QueryOptions());
            var bucket = await cluster.BucketAsync("Employees");
            var collection = bucket.DefaultCollection();

           await collection.RemoveAsync(id.ToString());
            return null;
        }

        public async Task<Employees> GetEmployeById(ICluster cluster, int id)
        {
            Employees employee = new Employees();
            var queryResult = await cluster.QueryAsync<Employees>("SELECT username,name,email,age,location,srccs,phoneNumber,salary,skill,managerName,address,id FROM Employees where id=" + id, new Couchbase.Query.QueryOptions());
         
            

            await foreach (var row in queryResult)
            {
                employee = row;
            }

            return employee;
        }

        public async Task<List<Employees>> GetEmployees(ICluster cluster)
        {
            var queryResult = await cluster.QueryAsync<Employees>("SELECT username,name,email,age,location,srccs,phoneNumber,salary,skill,managerName,address,id FROM Employees ", new Couchbase.Query.QueryOptions());
           
            List<Employees> empList = new List<Employees>();

            await foreach (var row in queryResult)
            {
                empList.Add(row);
            }

            return empList;
        }

        public async Task<ICluster> Initialize()
        {
            var cluster = await Cluster.ConnectAsync("couchbase://localhost", "adm", "sanjay753");
            return cluster;
        }

        public async Task<Employees> PutEmployeById(ICluster cluster ,int id, Employees value)
        {
            var bucket = await cluster.BucketAsync("Employees");
            var collection = bucket.DefaultCollection();
            await collection.UpsertAsync(id.ToString(),value);
          
            return null;

        }
        //create
        public async Task<Employees> PostEmploye(ICluster cluster, Employees value)
        {

            var bucket = await cluster.BucketAsync("Employees");
            var collection = bucket.DefaultCollection();
            int idvalue = value.id;
           await collection.InsertAsync( idvalue.ToString(),value );
      

            return null;
        }

       
    }
}
